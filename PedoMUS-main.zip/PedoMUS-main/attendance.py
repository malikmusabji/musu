import streamlit as st

def attendance_page():
    st.title("Attendance Page")
    st.markdown("""The Attendance page is a time-locked page preventing acess to other websites while in use, and automatically marks your attendance when in class.""")